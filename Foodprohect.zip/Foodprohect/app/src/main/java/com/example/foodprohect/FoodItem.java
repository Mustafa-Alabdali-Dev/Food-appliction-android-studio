package com.example.foodprohect;

public class FoodItem {
    private final String name;          // ADDED: final
    private final String description;   // ADDED: final
    private final double price;         // ADDED: final
    private final int imageResource;    // ADDED: final
    private int quantity;               // NOT final (can change)

    public FoodItem(String name, String description, double price, int imageResource) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.imageResource = imageResource;
        this.quantity = 0;
    }

    // Getters and setters
    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public int getImageResource() { return imageResource; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
}