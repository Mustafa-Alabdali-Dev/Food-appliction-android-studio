package com.example.foodprohect;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.PopupMenu;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Setup buttons - FIXED: Use correct ID with underscore
        Button signInButton = findViewById(R.id.sign_in_button); // CHANGED: sign_in_button
        Button loginButton = findViewById(R.id.login_button);

        // Sign In button goes to SignUpActivity (create account)
        signInButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, SignUpActivity.class);
            startActivity(intent);
        });

        // Login button goes to LoginActivity (existing users)
        loginButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            startActivity(intent);
        });

        // Setup options menu
        findViewById(R.id.options_menu).setOnClickListener(v -> showOptionsMenu());
    }

    private void showOptionsMenu() {
        PopupMenu popupMenu = new PopupMenu(this, findViewById(R.id.options_menu));
        popupMenu.getMenuInflater().inflate(R.menu.main_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.about) {
                showAboutDialog();
                return true;
            }
            return false;
        });
        popupMenu.show();
    }

    private void showAboutDialog() {
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("About")
                .setMessage("Developed by Mustafa Alabdali")
                .setPositiveButton("OK", null)
                .show();
    }
}