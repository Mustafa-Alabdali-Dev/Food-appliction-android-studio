package com.example.foodprohect;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale; // ADD THIS IMPORT

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.FoodViewHolder> {
    private final List<FoodItem> foodList; // ADDED: final
    private final OnItemClickListener listener; // ADDED: final

    public interface OnItemClickListener {
        void onAddToCartClick(FoodItem item);
    }

    public FoodAdapter(List<FoodItem> foodList, OnItemClickListener listener) {
        this.foodList = foodList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public FoodViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.food_item, parent, false);
        return new FoodViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FoodViewHolder holder, int position) {
        FoodItem item = foodList.get(position);
        holder.foodName.setText(item.getName());
        holder.foodDescription.setText(item.getDescription());
        holder.foodPrice.setText(String.format(Locale.US, "$%.2f", item.getPrice())); // FIXED: Locale
        holder.foodImage.setImageResource(item.getImageResource());

        holder.addToCartButton.setOnClickListener(v -> {
            FoodItem cartItem = new FoodItem(
                    item.getName(),
                    item.getDescription(),
                    item.getPrice(),
                    item.getImageResource()
            );
            cartItem.setQuantity(1);
            listener.onAddToCartClick(cartItem);
        });
    }

    @Override
    public int getItemCount() {
        return foodList.size();
    }

    // FIXED: Made public (RecyclerView needs access to this class)
    public static class FoodViewHolder extends RecyclerView.ViewHolder {
        ImageView foodImage;
        TextView foodName;
        TextView foodDescription;
        TextView foodPrice;
        Button addToCartButton;

        public FoodViewHolder(@NonNull View itemView) {
            super(itemView);
            foodImage = itemView.findViewById(R.id.food_image);
            foodName = itemView.findViewById(R.id.food_name);
            foodDescription = itemView.findViewById(R.id.food_description);
            foodPrice = itemView.findViewById(R.id.food_price);
            addToCartButton = itemView.findViewById(R.id.add_to_cart_button);
        }
    }
}