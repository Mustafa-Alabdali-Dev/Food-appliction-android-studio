package com.example.foodprohect;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale; // ADD THIS IMPORT

public class PaymentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        // Get total amount from cart
        double totalAmount = CartManager.getInstance().getTotalPrice();
        TextView totalAmountText = findViewById(R.id.total_amount);
        totalAmountText.setText(String.format(Locale.US, "Total: $%.2f", totalAmount)); // FIXED: Added Locale.US

        // Setup pay button
        Button payButton = findViewById(R.id.pay_button);
        payButton.setOnClickListener(v -> processPayment());
    }

    private void processPayment() {
        // Here you would integrate with actual payment gateway
        // For now, just show success message and clear cart

        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
        builder.setTitle("Payment Successful")
                .setMessage("Thank you for your order!")
                .setPositiveButton("OK", (dialog, which) -> {
                    CartManager.getInstance().clearCart();
                    // Navigate back to order page
                    Intent intent = new Intent(PaymentActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                })
                .show();
    }
}