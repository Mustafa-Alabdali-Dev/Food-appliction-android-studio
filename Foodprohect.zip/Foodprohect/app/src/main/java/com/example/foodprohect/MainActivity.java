package com.example.foodprohect;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements FoodAdapter.OnItemClickListener {
    // Removed: foodRecyclerView and foodAdapter fields
    private List<FoodItem> foodList;
    private TextView cartItemCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeFoodItems();
        setupRecyclerView();
        setupCartButton();
    }

    private void initializeFoodItems() {
        foodList = new ArrayList<>();
        // Add sample food items
        foodList.add(new FoodItem("Burger", "Delicious beef burger with cheese", 8.99, R.drawable.burger));
        foodList.add(new FoodItem("Pizza", "Pepperoni pizza with mozzarella", 12.99, R.drawable.pizza));
        foodList.add(new FoodItem("Pasta", "Creamy Alfredo pasta", 10.99, R.drawable.pasta));
        foodList.add(new FoodItem("Salad", "Fresh garden salad", 6.99, R.drawable.salad));
        foodList.add(new FoodItem("Fries", "Crispy golden fries", 3.99, R.drawable.fries));
        foodList.add(new FoodItem("Soda", "Refreshing soft drink", 1.99, R.drawable.soda));
    }

    private void setupRecyclerView() {
        // Converted to local variables
        RecyclerView foodRecyclerView = findViewById(R.id.food_recycler_view);
        foodRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        FoodAdapter foodAdapter = new FoodAdapter(foodList, this);
        foodRecyclerView.setAdapter(foodAdapter);
    }

    private void setupCartButton() {
        cartItemCount = findViewById(R.id.cart_item_count);
        updateCartItemCount();

        findViewById(R.id.cart_button).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CartActivity.class);
            startActivity(intent);
        });
    }

    @Override
    public void onAddToCartClick(FoodItem item) {
        CartManager.getInstance().addToCart(item);
        updateCartItemCount();
    }

    private void updateCartItemCount() {
        int count = CartManager.getInstance().getCartItemCount();
        cartItemCount.setText(String.valueOf(count));
        cartItemCount.setVisibility(count > 0 ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCartItemCount();
    }
}