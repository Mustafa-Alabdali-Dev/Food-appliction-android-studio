package com.example.foodprohect;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {
    private final List<FoodItem> cartItems;
    private final Runnable onDataChangeListener;

    public CartAdapter(List<FoodItem> cartItems, Runnable onDataChangeListener) {
        this.cartItems = cartItems;
        this.onDataChangeListener = onDataChangeListener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cart_item, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        FoodItem item = cartItems.get(position);
        holder.foodName.setText(item.getName());
        holder.foodPrice.setText(String.format(Locale.US, "$%.2f", item.getPrice()));
        holder.quantity.setText(String.valueOf(item.getQuantity()));
        holder.foodImage.setImageResource(item.getImageResource());

        holder.increaseButton.setOnClickListener(v -> {
            int currentPosition = holder.getBindingAdapterPosition();
            if (currentPosition != RecyclerView.NO_POSITION) {
                FoodItem currentItem = cartItems.get(currentPosition);
                currentItem.setQuantity(currentItem.getQuantity() + 1);
                holder.quantity.setText(String.valueOf(currentItem.getQuantity()));
                onDataChangeListener.run();
            }
        });

        holder.decreaseButton.setOnClickListener(v -> {
            int currentPosition = holder.getBindingAdapterPosition();
            if (currentPosition != RecyclerView.NO_POSITION) {
                FoodItem currentItem = cartItems.get(currentPosition);
                if (currentItem.getQuantity() > 1) {
                    currentItem.setQuantity(currentItem.getQuantity() - 1);
                    holder.quantity.setText(String.valueOf(currentItem.getQuantity()));
                    onDataChangeListener.run();
                } else {
                    cartItems.remove(currentPosition);
                    notifyItemRemoved(currentPosition);
                    CartManager.getInstance().removeFromCart(currentItem);
                    onDataChangeListener.run();
                }
            }
        });

        holder.removeButton.setOnClickListener(v -> {
            int currentPosition = holder.getBindingAdapterPosition();
            if (currentPosition != RecyclerView.NO_POSITION) {
                FoodItem currentItem = cartItems.get(currentPosition);
                cartItems.remove(currentPosition);
                notifyItemRemoved(currentPosition);
                CartManager.getInstance().removeFromCart(currentItem);
                onDataChangeListener.run();
            }
        });
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    public static class CartViewHolder extends RecyclerView.ViewHolder {
        ImageView foodImage;
        TextView foodName;
        TextView foodPrice;
        TextView quantity;
        Button increaseButton;
        Button decreaseButton;
        Button removeButton;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            foodImage = itemView.findViewById(R.id.food_image);
            foodName = itemView.findViewById(R.id.food_name);
            foodPrice = itemView.findViewById(R.id.food_price);
            quantity = itemView.findViewById(R.id.quantity);
            increaseButton = itemView.findViewById(R.id.increase_button);
            decreaseButton = itemView.findViewById(R.id.decrease_button);
            removeButton = itemView.findViewById(R.id.remove_button);
        }
    }
}