package com.example.foodprohect;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale; // ADD THIS IMPORT

public class CartActivity extends AppCompatActivity {
    // Removed: cartRecyclerView and cartAdapter fields
    private TextView totalPrice;
    private Button checkoutButton;
    private TextView emptyCartText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        initializeViews();
        setupRecyclerView();
        updateTotalPrice();
    }

    private void initializeViews() {
        totalPrice = findViewById(R.id.total_price);
        checkoutButton = findViewById(R.id.checkout_button);
        emptyCartText = findViewById(R.id.empty_cart_text);

        checkoutButton.setOnClickListener(v -> {
            if (CartManager.getInstance().getCartItems().isEmpty()) {
                androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
                builder.setTitle("Empty Cart")
                        .setMessage("Your cart is empty. Add some items first.")
                        .setPositiveButton("OK", null)
                        .show();
                return;
            }
            Intent intent = new Intent(CartActivity.this, PaymentActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.back_button).setOnClickListener(v -> finish());
    }

    private void setupRecyclerView() {
        List<FoodItem> cartItems = CartManager.getInstance().getCartItems();
        RecyclerView cartRecyclerView = findViewById(R.id.cart_recycler_view); // LOCAL VARIABLE

        if (cartItems.isEmpty()) {
            emptyCartText.setVisibility(View.VISIBLE);
            cartRecyclerView.setVisibility(View.GONE);
            checkoutButton.setVisibility(View.GONE);
        } else {
            emptyCartText.setVisibility(View.GONE);
            cartRecyclerView.setVisibility(View.VISIBLE);
            checkoutButton.setVisibility(View.VISIBLE);

            cartRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            CartAdapter cartAdapter = new CartAdapter(cartItems, this::updateTotalPrice); // LOCAL VARIABLE
            cartRecyclerView.setAdapter(cartAdapter);
        }
    }

    private void updateTotalPrice() {
        double total = CartManager.getInstance().getTotalPrice();
        totalPrice.setText(String.format(Locale.US, "Total: $%.2f", total)); // FIXED LOCALE

        if (CartManager.getInstance().getCartItems().isEmpty()) {
            setupRecyclerView();
        }
    }
}